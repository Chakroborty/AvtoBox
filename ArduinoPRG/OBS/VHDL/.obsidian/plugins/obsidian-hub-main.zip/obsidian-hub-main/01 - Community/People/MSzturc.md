---
aliases:
- Matthäus Szturc
tags:
- 
publish: true
---

# Matthäus Szturc

- GitHub: [MSzturc](https://github.com/MSzturc/) ^github
<!-- - Discord: `@` ^discord-->
- Website: <https://github.com/MSzturc> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%


## Author of

%% Begin Hub: Released contributions %%
### Plugins
- [[better-pdf-plugin|Better PDF Plugin]]
- [[obsidian-advanced-slides|Advanced Slides]]

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

<!--
### Others
-->

<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: [Sponsor @MSzturc on GitHub Sponsors](https://github.com/sponsors/MSzturc) ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

<!--
## Follow this author
-->

<!-- - [[YouTube Channels|On YouTube]]: <https://> ^youtube-->
<!-- - Twitter: <https://> ^twitter-->
<!-- - ... -->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/MSzturc.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/MSzturc.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>

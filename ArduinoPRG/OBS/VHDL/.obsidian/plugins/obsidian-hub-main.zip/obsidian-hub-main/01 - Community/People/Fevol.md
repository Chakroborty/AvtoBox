---
aliases:
- Fevol
tags:
- 
publish: true
---

# Fevol

- GitHub: [Fevol](https://github.com/Fevol/) ^github
- Discord: `@Fevol#9470` ^discord
- Website: <https://github.com/Fevol/> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%
CompSci student trying to make plugins for Obsidian, has too many interests for their own good.

## Author of

%% Begin Hub: Released contributions %%
### Plugins
- [[translate|Translate]]

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->


### Others
- [[Obsidian ecosystem statistics|Brief analysis on Obsidian's ecosystem]]

<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: [Sponsor @Fevol on GitHub Sponsors](https://github.com/sponsors/Fevol) ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

<!--
## Follow this author
-->

<!-- - [[YouTube Channels|On YouTube]]: <https://> ^youtube-->
<!-- - Twitter: <https://> ^twitter-->
<!-- - ... -->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Fevol.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Fevol.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>

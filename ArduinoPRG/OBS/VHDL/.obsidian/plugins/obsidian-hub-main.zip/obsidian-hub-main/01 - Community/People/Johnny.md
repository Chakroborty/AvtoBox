---
aliases:
- Johnny ✨
tags:
- seedling
publish: true
---

# Johnny

- GitHub: [jsmorabito (johnny1093) · GitHub](https://github.com/jsmorabito) ^github
- Discord: `@johnny1093#3137` ^discord
<!-- - Website: <https://> ^website-->
 - [Home - John S. Morabito Jr. ✨ - Obsidian Publish](https://publish.obsidian.md/johnmorabito/Home) ^publish

%% Feel free to add a bio below this comment %%


## Author of

%% Begin Hub: Released contributions %%


### Plugins

- [[cmdr|Commander]]
- [[workspaces-plus|Workspaces Plus]]

<!--
### Themes
-->

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->


### Others

- [[Obsidian Design System Community File]]

<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: [Sponsor @Johnny on GitHub Sponsors](https://github.com/sponsors/Johnny) ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

<!--
## Follow this author
-->

<!-- - [[YouTube Channels|On YouTube]]: <https://> ^youtube-->
<!-- - Twitter: <https://> ^twitter-->
<!-- - ... -->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Johnny.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Johnny.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>

---
aliases:
- 
tags: 
- seedling 
publish: true
---


# {{title}}

%% Add a description below this line. It doesn't need to be long: one or two sentences should be a good start. %%
#placeholder/description 

## Tools in this category

%% Add a bullet here and link to the plugins you'd like to categorize! %%

## Related categories

%% Add links to other 02.04 - Category notes %%

#placeholder/notes

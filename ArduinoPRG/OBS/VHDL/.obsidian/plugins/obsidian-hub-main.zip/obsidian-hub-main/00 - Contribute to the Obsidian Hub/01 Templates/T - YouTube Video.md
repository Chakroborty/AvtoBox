---
aliases: 
- 
tags:
- seedling
publish: true
---

# {{title}}

By #placeholder/author

%% Add one or two sentences describing the video and link it to at least one other note %%
#placeholder/description 

%% In the tag below, plase fill out the #placeholder/link and then remove this comment%%

<iframe width="100%" height="400px" src="#placeholder/link" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

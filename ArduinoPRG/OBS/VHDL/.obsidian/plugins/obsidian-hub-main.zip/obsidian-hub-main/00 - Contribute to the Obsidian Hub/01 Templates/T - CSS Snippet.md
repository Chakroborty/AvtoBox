---
aliases: 
- 
tags:
- seedling
publish: true
---

# {{title}}

%% Add a description below and remove the tag. What do you use this css snippet for? Feel free to add links to other existing notes! %% 
#placeholder/description 

%% Paste your template below %%

```css

```

%% Add a screenshot of the effect this snippet produces with edit and preview mode visible %%
#placeholder/screenshot

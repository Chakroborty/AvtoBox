# Contributing templates to the community vault
1. Create a new file under [[🗂️ Templates]] (if you can, file it under the right subfolder).
2. Apply the [[T - Templates]] template
3. Fill out any placeholders
4. [[How to add content through GitHub|Submit your changes to GitHub]]

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/Contributing%20templates%20to%20the%20community%20vault.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/Contributing%20templates%20to%20the%20community%20vault.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>

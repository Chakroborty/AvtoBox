---
aliases:
  -
tags:
  - seedling
publish: true
---

# {{title}}

Official website: #placeholder/link
Documentation: #placeholder/link
Cost: #placeholder/tool
Available for: #placeholder/tool %% Uncomment this and remove those that don't apply: [[Windows Tools|Windows]], [[MacOS Tools|MacOS]], [[Linux Tools|Linux]], [[Android Apps|Android]], [[iOS Apps|iOS]], [[iPadOS Apps|iPadOS]] %%

%% Add a description below this line. It doesn't need to be long: one or two sentences should be a good start. Mention [[🗂️ Auxiliary Tools]] or [[🗂️ 02.04 Auxiliary Tools by Category]] and any other relevant notes in this vault. %%

#placeholder/description

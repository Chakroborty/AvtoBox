---
aliases: 
- 
tags:
- seedling
publish: true
---

%% Use search and replace to automatically update these GitHub badges
- Search for: `{{repo}}`
- Replace with: `user/repository` including the forward slash, e.g. `Dmitriy-Shulha/obsidian-css-snippets`
%%

![GitHub all releases](https://img.shields.io/github/downloads/{{repo}}/total?color=573E7A&logo=github&style=for-the-badge) * ![GitHub manifest version](https://img.shields.io/github/manifest-json/v/{{repo}}?color=573E7A&logo=github&style=for-the-badge) * ![GitHub issues by-label](https://img.shields.io/github/issues/{{repo}}/help%20wanted?color=573E7A&logo=github&style=for-the-badge) * ![GitHub Repo stars](https://img.shields.io/github/stars/{{repo}}?color=573E7A&logo=github&style=for-the-badge)

# {{title}}

Repository: [GitHub](https://github.com/{{repo}})

%% Add a description below and remove the tag. What do you use this css snippet for? If it's a repository, what sort of snippets are stored here? Feel free to add links to other existing notes! %% 
#placeholder/description 


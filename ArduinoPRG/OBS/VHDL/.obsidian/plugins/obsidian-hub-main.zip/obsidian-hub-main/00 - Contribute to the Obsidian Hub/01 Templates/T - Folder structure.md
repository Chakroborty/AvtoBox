---
aliases: 
- 
tags:
- seedling
publish: true
---

# {{title}}

%% Optional: Add a screenshot
#placeholder/screenshot 
Remove this comment once you're done or if you'll be using another approach mentioned in [[🗂️ Vaults]]
%%
%% Add a description below this comment. It doesn't need to be long: one or two sentences should be a good start. 

Longer descriptions are also welcome! A few things you could cover are: 
- What do you use each folder for?
- Do you use any plugins to keep you organized? - Add links to them from 02.01
- Any custom CSS? 
	- Add links to 04 - Community themes or 05 - CSS Snippets or any other 10 - Resources
%%

#placeholder/description 



---
aliases: 
- 
tags:
- seedling
publish: true
---

# {{title}}

%% Add a description below and remove the tag. What do you use this template for? Feel free to add links to the type of template it is or other existing notes! %% 
#placeholder/description 

%% Paste your template below %%

```markdown

```
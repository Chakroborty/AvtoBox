---
aliases: 
- 
tags:
- seedling
publish: true
---

# {{title}}

%% Match the title with the channel's title %% 

%% Add the link (replacing #placeholder/link below) and then remove this comment%%
Link: [YouTube](placeholder/link)

Hosted by #placeholder/author.

%% Add a few sentences of what sort of videos they produce, feel free to link to other notes (e.g. after creating a note for a YouTube video you liked) %% 
#placeholder/description 

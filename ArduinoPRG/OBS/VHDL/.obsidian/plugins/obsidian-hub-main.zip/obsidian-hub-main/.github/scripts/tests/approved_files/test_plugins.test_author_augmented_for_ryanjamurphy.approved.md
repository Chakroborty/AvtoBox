{
    "author": "Ryan J. A. Murphy",
    "authorUrl": "https://axle.design",
    "description": "Open or reveal the current note in DEVONthink.",
    "id": "DEVONlink-obsidian",
    "isDesktopOnly": true,
    "minAppVersion": "0.9.12",
    "mobile": "[[Desktop-only plugins|No]]",
    "name": "DEVONlink",
    "repo": "ryanjamurphy/DEVONlink-obsidian",
    "user": "ryanjamurphy",
    "version": "2.2.1"
}

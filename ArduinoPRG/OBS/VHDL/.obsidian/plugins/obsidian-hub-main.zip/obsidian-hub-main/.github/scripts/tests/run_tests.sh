#!/usr/bin/env sh

# -s means "show console output if test fails"
python3 -m pytest -s --verbose
